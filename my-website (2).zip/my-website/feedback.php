<?php
date_default_timezone_set('Europe/Moscow');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 20px; border: 2px solid #007bff; border-radius: 8px; background-color: #e3f2fd;'>";
    echo "<h2 style='color: #007bff; margin-top: 0;'>Данные XAMPP</h2>";
    
    echo "<p><b>ФИО:</b> " . htmlspecialchars($_POST['fullname'] ?? 'Не указано') . "</p>";
    echo "<p><b>Email:</b> " . htmlspecialchars($_POST['email'] ?? 'Не указано') . "</p>";
    
    $source = $_POST['source'] ?? 'Не выбрано';
    $source_text = ($source === 'internet') ? 'Из интернета' : (($source === 'friends') ? 'От друзей' : 'Не указано');
    echo "<p><b>Откуда узнали о нас:</b> " . htmlspecialchars($source_text) . "</p>";
    
    $appeal_type = $_POST['appeal_type'] ?? '';
    $appeal_text = ($appeal_type === 'proposal') ? 'Предложение' : (($appeal_type === 'complaint') ? 'Жалоба' : 'Не выбрано');
    echo "<p><b>Тип обращения:</b> " . htmlspecialchars($appeal_text) . "</p>";
    
    echo "<p><b>Текст сообщения:</b><br>" . nl2br(htmlspecialchars($_POST['message'] ?? '')) . "</p>";
    
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        echo "<p style='color: green;'><b>Вложение:</b> Файл успешно загружен (" . htmlspecialchars($_FILES['attachment']['name']) . ")</p>";
    } else {
        echo "<p style='color: #777;'><b>Вложение:</b> Файл не прикреплен или произошла ошибка загрузки.</p>";
    }
    
    $agreement = isset($_POST['agreement']) ? 'Дано' : 'Нет';
    echo "<p><b>Согласие на обработку персональных данных:</b> " . $agreement . "</p>";
    
    echo "<br><a href='feedback.php' style='display: inline-block; padding: 10px 15px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;'>Вернуться к форме</a>";
    echo "</div>";
    exit; 
}

$page_title = "Форма обратной связи";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
    <a href="<?php $name='Главная'; $link='index.php'; $current_page=($page_title=='Главная страница'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
    <a href="<?php $name='Обратная связь'; $link='feedback.php'; $current_page=($page_title=='Форма обратной связи'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
    <a href="<?php $name='Вход'; $link='login.php'; $current_page=($page_title=='Аутентификация'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
	</nav>

    </header>

    <main class="container">
        <h2>Обратная связь</h2>
        <form action="feedback.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="fullname">ФИО:</label>
                <input type="text" id="fullname" name="fullname" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Откуда узнали о нас?</label>
                <div class="radio-group">
                    <input type="radio" id="src-internet" name="source" value="internet">
                    <label for="src-internet">Из интернета</label>
                    <input type="radio" id="src-friends" name="source" value="friends">
                    <label for="src-friends">От друзей</label>
                </div>
            </div>
            <div class="form-group">
                <label for="appeal-type">Тип обращения:</label>
                <select id="appeal-type" name="appeal_type">
                    <option value="proposal">Предложение</option>
                    <option value="complaint">Жалоба</option>
                </select>
            </div>
            <div class="form-group">
                <label for="message">Текст сообщения:</label>
                <textarea id="message" name="message" rows="5" required></textarea>
            </div>
            <div class="form-group">
                <label for="file-attachment">Вложения:</label>
                <input type="file" id="file-attachment" name="attachment">
            </div>
            <div class="form-group checkbox-group">
                <input type="checkbox" id="agreement" name="agreement" value="yes" required>
                <label for="agreement">Даю согласие на обработку персональных данных</label>
            </div>
            <button type="submit" class="btn">Отправить</button>
        </form>
    </main>

    <footer>
        <p>Сформировано <?php echo date('d.m.Y в H-i:s'); ?></p>
    </footer>
</body>
</html>
