<?php
date_default_timezone_set('Europe/Moscow');

$page_title = "Аутентификация";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div style='font-family: Arial, sans-serif; max-width: 400px; margin: 80px auto; padding: 30px; border: 2px solid #007bff; border-radius: 8px; background-color: #e3f2fd; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;'>";
    echo "<h2 style='color: #007bff; margin-top: 0;'>Данные XAMPP</h2>";
    echo "<p style='font-size: 1.1em; margin: 15px 0;'><b>Логин:</b> " . htmlspecialchars($_POST['username']) . "</p>";
    echo "<p style='font-size: 1.1em; margin: 15px 0;'><b>Пароль:</b> " . htmlspecialchars($_POST['password']) . "</p>";
    echo "<br><a href='login.php' style='display: inline-block; padding: 12px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px; font-weight: bold; width: 100%; box-sizing: border-box;'>Вернуться к форме</a>";
    echo "</div>";
    exit; 
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="auth-body">
    <header>
        <nav>
            <a href="<?php $name='Главная'; $link='index.php'; $current_page=($page_title=='Главная страница'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
            <a href="<?php $name='Обратная связь'; $link='feedback.php'; $current_page=($page_title=='Форма обратной связи'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
            <a href="<?php $name='Вход'; $link='login.php'; $current_page=($page_title=='Аутентификация'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
        </nav>
    </header>
    <div class="auth-wrapper">
        <div class="auth-card">
            <h2>Вход в систему</h2>
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="username">Логин:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group checkbox-group">
                    <input type="checkbox" id="remember" name="remember" value="yes">
                    <label for="remember">Запомнить меня</label>
                </div>
                <button type="submit" class="btn btn-full">Войти</button>
            </form>
        </div>
    </div>
    <footer>
        <p>Сформировано <?php echo date('d.m.Y в H-i:s'); ?></p>
    </footer>
</body>
</html>
