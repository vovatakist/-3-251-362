<?php
date_default_timezone_set('Europe/Moscow');

$page_title = "Главная страница";

$skills_list = [
    "Изучение основ синтаксиса языка PHP",
    "Изучение назначений и возможностей PHP",
    "Обучение работы с FTP-сервером",
    "Получение навыков работы с средой программирования"
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Добро пожаловать на мой сайт!</h1>
        <nav>
    <a href="<?php $name='Главная'; $link='index.php'; $current_page=($page_title=='Главная страница'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
    <a href="<?php $name='Обратная связь'; $link='feedback.php'; $current_page=($page_title=='Форма обратной связи'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
    <a href="<?php $name='Вход'; $link='login.php'; $current_page=($page_title=='Аутентификация'); echo $link; ?>"<?php if($current_page) echo ' class="selected_menu"'; ?>><?php echo $name; ?></a>
	</nav>
    </header>

    <main class="container">
        <section id="about">
            <h2>О себе</h2>
            <p>Меня зовут Шарандина Полина. Я учусь разработке бизнес приложений и создаю свою первую страничку.</p>
            
            <?php
            if (date('s') % 2 === 0) {
                $photo_name = 'photo.jpg.jpg'; 
                $alt_text = 'Моя основная фотография';
            } else {
                $photo_name = 'photo2.jpg';    
                $alt_text = 'Альтернативная фотография';
            }
            echo '<img src="' . $photo_name . '" alt="' . $alt_text . '" style="max-width:200px; display:block; margin:20px 0; border-radius: 50%;">';
            ?>
        </section>

        <section id="skills">
            <h2>План обучения на втором курсе (2026-2027)</h2>
            <p>Ниже представлена таблица с планом обучения и списком дисциплин, которые я изучаю в этом году:</p>
            
            <table>
                <tr>
                    <th>Период 3 (Семестр/Модуль)</th>
                    <th>Период 4 (Семестр/Модуль)</th>
                </tr>
                <tr><td>Иностранный язык</td><td>Иностранный язык</td></tr>
                <tr><td>Математическая логика и теория алгоритмов</td><td>Дискретные структуры и компьютинг</td></tr>
                <tr><td>Шаблоны проектирования приложений</td><td>Теория вероятностей и мат. статистика</td></tr>
                <tr><td>Основы разработки КИС</td><td>Сети и системы передачи информации</td></tr>
                <tr><td>Проектирование баз данных</td><td>Разработка корпоративных ИС</td></tr>
                <tr><td>Язык SQL</td><td>Веб-разработка</td></tr>
                <tr><td>Основы веб-технологий</td><td>Моделирование бизнес-процессов</td></tr>
                <tr><td>Структурное проектирование</td><td>Основы тех. предпринимательства</td></tr>
                <tr><td>Основы бухгалтерского учёта</td><td>-</td></tr>
                <tr><td>Инженерная коммуникация в IT</td><td>-</td></tr>
            </table>

            <h2>Цели и задачи текущей лабораторной работы</h2>
            <ul>
                <?php
                foreach ($skills_list as $item) {
                    echo "<li>" . $item . "</li>";
                }
                ?>
            </ul>
        </section>
    </main>

    <footer>
        <p>Сформировано <?php echo date('d.m.Y в H-i:s'); ?></p>
        <p>&copy; 2026</p>
    </footer>
</body>
</html>
